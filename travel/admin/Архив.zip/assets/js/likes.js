$(document).ready(function() {
    let table;
    
    // Initialize DataTables
    function initDataTable(filters = {}) {
        if (table) {
            table.destroy();
        }
        
        table = $('#likesTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '../api/likes/get_all_likes.php',
                type: 'GET',
                data: function(d) {
                    // Map DataTables parameters to our API
                    return {
                        page: Math.floor(d.start / d.length) + 1,
                        per_page: d.length,
                        search: d.search.value,
                        sort_by: getSortColumn(d.order[0].column),
                        sort_order: d.order[0].dir,
                        user_id: filters.user_id || '',
                        photo_id: filters.photo_id || ''
                    };
                },
                dataSrc: function(json) {
                    if (!json.success) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Ошибка',
                            text: json.message || 'Не удалось загрузить данные'
                        });
                        return [];
                    }
                    
                    // Set total records for pagination
                    json.recordsTotal = json.pagination.total;
                    json.recordsFiltered = json.pagination.total;
                    
                    return json.likes;
                },
                error: function(xhr, error, thrown) {
                    console.error('DataTables error:', error, thrown);
                    Swal.fire({
                        icon: 'error',
                        title: 'Ошибка загрузки',
                        text: 'Не удалось загрузить данные. Проверьте консоль для деталей.'
                    });
                }
            },
            columns: [
                { 
                    data: 'id',
                    width: '50px'
                },
                { 
                    data: null,
                    render: function(data, type, row) {
                        let img = row.userProfileImage ? 
                            `<img src="../../../${row.userProfileImage}" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">` :
                            `<div class="rounded-circle bg-secondary d-inline-block me-2" style="width: 30px; height: 30px;"></div>`;
                        return img + escapeHtml(row.userName);
                    },
                    orderable: true
                },
                { 
                    data: 'userEmail',
                    render: function(data) {
                        return escapeHtml(data);
                    }
                },
                { 
                    data: 'photoTitle',
                    render: function(data, type, row) {
                        return `<a href="#" class="text-decoration-none" onclick="viewPhoto(${row.photoId}); return false;">
                                    ${escapeHtml(data || 'Без названия')}
                                </a>`;
                    },
                    orderable: true
                },
                { 
                    data: 'locationName',
                    render: function(data) {
                        return escapeHtml(data || 'Не указана');
                    }
                },
                { 
                    data: 'createdAt',
                    render: function(data) {
                        return formatDateTime(data);
                    },
                    orderable: true
                },
                { 
                    data: 'photoPreview',
                    render: function(data, type, row) {
                        if (data) {
                            return `<img src="../../../${data}" class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover; cursor: pointer;" 
                                    onclick="showImagePreview('../../../${data}')" 
                                    title="Нажмите для увеличения">`;
                        }
                        return '<span class="text-muted">Нет изображения</span>';
                    },
                    orderable: false
                }
            ],
            order: [[5, 'desc']], // Sort by created_at descending by default
            pageLength: 50,
            lengthMenu: [[25, 50, 100], [25, 50, 100]],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/ru.json'
            },
            dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip'
        });
    }
    
    // Get sort column name
    function getSortColumn(columnIndex) {
        const columns = ['id', 'user_name', 'userEmail', 'photo_title', 'locationName', 'created_at', 'photoPreview'];
        return columns[columnIndex] || 'created_at';
    }
    
    // Initialize table on page load
    initDataTable();
    
    // Handle filter form submission
    $('#filterForm').on('submit', function(e) {
        e.preventDefault();
        
        const filters = {
            user_id: $('#userFilter').val(),
            photo_id: $('#photoFilter').val()
        };
        
        initDataTable(filters);
    });
    
    // Handle reset filters
    $('#resetFilters').on('click', function() {
        $('#filterForm')[0].reset();
        initDataTable();
    });
    
    // View photo details (placeholder function)
    window.viewPhoto = function(photoId) {
        Swal.fire({
            title: 'Просмотр поста',
            text: `ID поста: ${photoId}`,
            icon: 'info'
        });
    };
    
    // Show image preview
    window.showImagePreview = function(imagePath) {
        Swal.fire({
            imageUrl: imagePath,
            imageAlt: 'Превью фотографии',
            showCloseButton: true,
            showConfirmButton: false,
            width: 'auto',
            customClass: {
                image: 'img-fluid'
            }
        });
    };
    
    // Escape HTML to prevent XSS
    function escapeHtml(text) {
        if (!text) return '';
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.toString().replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
    // Format datetime
    function formatDateTime(datetime) {
        if (!datetime) return '';
        const date = new Date(datetime);
        return date.toLocaleString('ru-RU', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
});
