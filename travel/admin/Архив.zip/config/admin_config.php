<?php
// Подключаем основную конфигурацию
require_once __DIR__ . '/../../config.php';

// Функция для проверки авторизации администратора
function adminRequireAuth() {
    // Проверяем, не запущена ли уже сессия
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    // Проверяем наличие сессии администратора
    if (!isset($_SESSION['admin_id'])) {
        // Если это API запрос, возвращаем JSON
        if (strpos($_SERVER['REQUEST_URI'], '/api/') !== false) {
            header('HTTP/1.1 401 Unauthorized');
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode([
                'success' => false, 
                'message' => 'Требуется авторизация администратора',
                'errorCode' => 'AUTH_REQUIRED'
            ]);
            exit;
        }
        
        // Для обычных страниц перенаправляем на страницу входа
        header('Location: /travel/admin/login.php');
        exit;
    }
    
    return $_SESSION['admin_id'];
}

// Функция для авторизации администратора
function adminLogin($username, $password) {
    $db = connectToDatabase();
    
    try {
        // Проверяем количество попыток входа
        $attemptsCheck = checkLoginAttempts($username);
        if (!$attemptsCheck['allowed']) {
            return [
                'success' => false,
                'message' => $attemptsCheck['message']
            ];
        }
        
        // Получаем данные администратора по имени пользователя
        $stmt = $db->prepare("SELECT id, username, password_hash, email FROM admin_users WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Проверяем существование пользователя и правильность пароля
        if (!$admin || !password_verify($password, $admin['password_hash'])) {
            // Записываем неудачную попытку входа
            recordLoginAttempt($username, false);
            
            return [
                'success' => false,
                'message' => 'Неверное имя пользователя или пароль'
            ];
        }
        
        // Запускаем сессию, если она еще не запущена
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        
        // Сохраняем данные администратора в сессии
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['admin_email'] = $admin['email'];
        
        // Обновляем время последнего входа
        $updateStmt = $db->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = ?");
        $updateStmt->execute([$admin['id']]);
        
        // Записываем успешную попытку входа
        recordLoginAttempt($username, true);
        
        // Логируем успешный вход
        logAdminAction('login', ['username' => $username]);
        
        return [
            'success' => true,
            'message' => 'Успешная авторизация',
            'admin' => [
                'id' => $admin['id'],
                'username' => $admin['username'],
                'email' => $admin['email']
            ]
        ];
        
    } catch (PDOException $e) {
        error_log("Admin login error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Ошибка при авторизации'
        ];
    }
}

// Функция для выхода из системы
function adminLogout() {
    // Запускаем сессию, если она еще не запущена
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    // Логируем выход
    if (isset($_SESSION['admin_id'])) {
        logAdminAction('logout', ['username' => $_SESSION['admin_username'] ?? 'unknown']);
    }
    
    // Удаляем все данные сессии
    $_SESSION = array();
    
    // Удаляем cookie сессии
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Уничтожаем сессию
    session_destroy();
    
    return [
        'success' => true,
        'message' => 'Вы успешно вышли из системы'
    ];
}

// Функция для получения данных текущего администратора
function getAdminData() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['admin_id'])) {
        return null;
    }
    
    return [
        'id' => $_SESSION['admin_id'],
        'username' => $_SESSION['admin_username'] ?? '',
        'email' => $_SESSION['admin_email'] ?? ''
    ];
}

// Функция для обработки ошибок админки
function adminHandleError($message, $statusCode = 500, $errorCode = null) {
    $statusTexts = [
        400 => 'Bad Request',
        401 => 'Unauthorized',
        403 => 'Forbidden',
        404 => 'Not Found',
        405 => 'Method Not Allowed',
        500 => 'Internal Server Error'
    ];
    
    $text = isset($statusTexts[$statusCode]) ? $statusTexts[$statusCode] : 'Error';
    header("HTTP/1.1 {$statusCode} {$text}");
    header('Content-Type: application/json; charset=UTF-8');
    
    echo json_encode([
        'success' => false,
        'message' => $message,
        'errorCode' => $errorCode
    ]);
    exit;
}

// ============================================
// CSRF Protection Functions
// ============================================

// Функция для генерации CSRF токена
function generateCsrfToken() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
    return $_SESSION['csrf_token'];
}

// Функция для проверки CSRF токена
function verifyCsrfToken($token) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['csrf_token'])) {
        return false;
    }
    
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Функция для получения CSRF токена из запроса
function getCsrfTokenFromRequest() {
    // Проверяем в заголовках
    if (isset($_SERVER['HTTP_X_CSRF_TOKEN'])) {
        return $_SERVER['HTTP_X_CSRF_TOKEN'];
    }
    
    // Проверяем в POST данных
    if (isset($_POST['csrf_token'])) {
        return $_POST['csrf_token'];
    }
    
    // Проверяем в JSON body
    $json = file_get_contents('php://input');
    if ($json) {
        $data = json_decode($json, true);
        if (isset($data['csrf_token'])) {
            return $data['csrf_token'];
        }
    }
    
    return null;
}

// Функция для проверки CSRF токена в запросе
function requireCsrfToken() {
    $token = getCsrfTokenFromRequest();
    
    if (!$token || !verifyCsrfToken($token)) {
        adminHandleError('Недействительный CSRF токен', 403, 'INVALID_CSRF_TOKEN');
    }
}

// ============================================
// Input Validation Functions
// ============================================

// Функция для валидации целого числа
function validateInt($value, $min = null, $max = null) {
    if (!is_numeric($value)) {
        return false;
    }
    
    $intValue = intval($value);
    
    if ($min !== null && $intValue < $min) {
        return false;
    }
    
    if ($max !== null && $intValue > $max) {
        return false;
    }
    
    return $intValue;
}

// Функция для валидации строки
function validateString($value, $minLength = 0, $maxLength = null) {
    if (!is_string($value)) {
        return false;
    }
    
    $length = mb_strlen($value);
    
    if ($length < $minLength) {
        return false;
    }
    
    if ($maxLength !== null && $length > $maxLength) {
        return false;
    }
    
    return trim($value);
}

// Функция для валидации email
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Функция для валидации даты
function validateDate($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

// Функция для безопасного получения параметра из GET/POST
function getParam($name, $default = null, $type = 'string') {
    $value = $_GET[$name] ?? $_POST[$name] ?? $default;
    
    if ($value === null || $value === '') {
        return $default;
    }
    
    switch ($type) {
        case 'int':
            return validateInt($value) !== false ? intval($value) : $default;
        case 'string':
            return validateString($value) !== false ? trim($value) : $default;
        case 'email':
            return validateEmail($value) !== false ? $value : $default;
        default:
            return $value;
    }
}

// Функция для безопасного вывода HTML
function escapeHtml($value) {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

// ============================================
// Admin Logging Functions
// ============================================

// Функция для логирования действий администратора
function logAdminAction($action, $details = null, $targetType = null, $targetId = null) {
    $db = connectToDatabase();
    
    try {
        $adminId = $_SESSION['admin_id'] ?? null;
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        $stmt = $db->prepare("
            INSERT INTO admin_logs 
            (admin_id, action, details, target_type, target_id, ip_address, user_agent, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $adminId,
            $action,
            $details ? json_encode($details) : null,
            $targetType,
            $targetId,
            $ipAddress,
            $userAgent
        ]);
        
        return true;
    } catch (PDOException $e) {
        error_log("Admin logging error: " . $e->getMessage());
        return false;
    }
}

// ============================================
// Brute Force Protection Functions
// ============================================

// Функция для проверки количества попыток входа
function checkLoginAttempts($username) {
    $db = connectToDatabase();
    
    try {
        // Получаем количество неудачных попыток за последние 15 минут
        $stmt = $db->prepare("
            SELECT COUNT(*) as attempts 
            FROM login_attempts 
            WHERE username = ? 
            AND success = 0 
            AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
        ");
        $stmt->execute([$username]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $attempts = $result['attempts'] ?? 0;
        
        // Максимум 5 попыток за 15 минут
        if ($attempts >= 5) {
            return [
                'allowed' => false,
                'attempts' => $attempts,
                'message' => 'Слишком много неудачных попыток входа. Попробуйте через 15 минут.'
            ];
        }
        
        return [
            'allowed' => true,
            'attempts' => $attempts
        ];
    } catch (PDOException $e) {
        error_log("Check login attempts error: " . $e->getMessage());
        return ['allowed' => true, 'attempts' => 0];
    }
}

// Функция для записи попытки входа
function recordLoginAttempt($username, $success, $ipAddress = null) {
    $db = connectToDatabase();
    
    try {
        if ($ipAddress === null) {
            $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        }
        
        $stmt = $db->prepare("
            INSERT INTO login_attempts 
            (username, success, ip_address, attempted_at) 
            VALUES (?, ?, ?, NOW())
        ");
        
        $stmt->execute([$username, $success ? 1 : 0, $ipAddress]);
        
        return true;
    } catch (PDOException $e) {
        error_log("Record login attempt error: " . $e->getMessage());
        return false;
    }
}

// Функция для очистки старых попыток входа
function cleanupOldLoginAttempts() {
    $db = connectToDatabase();
    
    try {
        // Удаляем попытки старше 24 часов
        $stmt = $db->prepare("
            DELETE FROM login_attempts 
            WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ");
        $stmt->execute();
        
        return true;
    } catch (PDOException $e) {
        error_log("Cleanup login attempts error: " . $e->getMessage());
        return false;
    }
}
