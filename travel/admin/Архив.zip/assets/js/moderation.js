let currentPage = 1;
let currentFilters = {};
let selectedPhotos = new Set();

document.addEventListener('DOMContentLoaded', function() {
    loadPhotos();
    
    // Filter form submission
    document.getElementById('filterForm').addEventListener('submit', function(e) {
        e.preventDefault();
        applyFilters();
    });
    
    // Reset filters
    document.getElementById('resetFilters').addEventListener('click', function() {
        document.getElementById('filterForm').reset();
        currentFilters = {};
        currentPage = 1;
        selectedPhotos.clear();
        updateSelectedCount();
        loadPhotos();
    });
    
    // Select all checkbox
    document.getElementById('selectAll').addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.photo-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
            const photoId = parseInt(checkbox.dataset.photoId);
            if (this.checked) {
                selectedPhotos.add(photoId);
            } else {
                selectedPhotos.delete(photoId);
            }
        });
        updateSelectedCount();
    });
    
    // Bulk delete button
    document.getElementById('bulkDeleteBtn').addEventListener('click', function() {
        if (selectedPhotos.size === 0) return;
        
        Swal.fire({
            title: 'Подтверждение удаления',
            text: `Вы уверены, что хотите удалить ${selectedPhotos.size} фотографий? Это действие нельзя отменить.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Да, удалить',
            cancelButtonText: 'Отмена'
        }).then((result) => {
            if (result.isConfirmed) {
                bulkDeletePhotos();
            }
        });
    });
});

function applyFilters() {
    currentFilters = {};
    
    const userId = document.getElementById('filterUser').value;
    const dateFrom = document.getElementById('filterDateFrom').value;
    const dateTo = document.getElementById('filterDateTo').value;
    
    if (userId) currentFilters.user_id = userId;
    if (dateFrom) currentFilters.date_from = dateFrom;
    if (dateTo) currentFilters.date_to = dateTo;
    
    currentPage = 1;
    selectedPhotos.clear();
    updateSelectedCount();
    loadPhotos();
}

function loadPhotos() {
    const gallery = document.getElementById('photoGallery');
    const loading = document.getElementById('loadingSpinner');
    const noPhotos = document.getElementById('noPhotos');
    
    gallery.style.display = 'none';
    loading.style.display = 'block';
    noPhotos.style.display = 'none';
    
    const params = new URLSearchParams({
        page: currentPage,
        per_page: 24,
        ...currentFilters
    });
    
    fetch(`../api/moderation/get_all_photos.php?${params}`)
        .then(response => response.json())
        .then(data => {
            loading.style.display = 'none';
            
            if (data.success && data.photos.length > 0) {
                displayPhotos(data.photos);
                displayPagination(data.pagination);
                gallery.style.display = 'flex';
            } else {
                noPhotos.style.display = 'block';
            }
        })
        .catch(error => {
            console.error('Error loading photos:', error);
            loading.style.display = 'none';
            Swal.fire('Ошибка', 'Не удалось загрузить фотографии', 'error');
        });
}

function displayPhotos(photos) {
    const gallery = document.getElementById('photoGallery');
    gallery.innerHTML = '';
    
    photos.forEach(photo => {
        const col = document.createElement('div');
        col.className = 'col-md-3 col-sm-4 col-6';
        
        const isSelected = selectedPhotos.has(photo.id);
        
        col.innerHTML = `
            <div class="card photo-card h-100" data-photo-id="${photo.id}">
                <div class="position-relative">
                    <img src="${escapeHtml(photo.filePath)}" 
                         class="card-img-top photo-thumbnail" 
                         alt="${escapeHtml(photo.title || 'Photo')}"
                         style="height: 200px; object-fit: cover; cursor: pointer;">
                    <div class="position-absolute top-0 start-0 p-2">
                        <input type="checkbox" 
                               class="form-check-input photo-checkbox" 
                               data-photo-id="${photo.id}"
                               ${isSelected ? 'checked' : ''}>
                    </div>
                    <button class="btn btn-sm btn-danger position-absolute top-0 end-0 m-2 delete-photo-btn"
                            data-photo-id="${photo.id}">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
                <div class="card-body p-2">
                    <h6 class="card-title mb-1 text-truncate" title="${escapeHtml(photo.title || 'Без названия')}">
                        ${escapeHtml(photo.title || 'Без названия')}
                    </h6>
                    <p class="card-text small mb-1">
                        <i class="bi bi-person"></i> ${escapeHtml(photo.userName)}
                    </p>
                    ${photo.locationName ? `
                        <p class="card-text small mb-1">
                            <i class="bi bi-geo-alt"></i> ${escapeHtml(photo.locationName)}
                        </p>
                    ` : ''}
                    <p class="card-text small text-muted mb-1">
                        <i class="bi bi-calendar"></i> ${formatDate(photo.createdAt)}
                    </p>
                    ${photo.inAlbums.length > 0 ? `
                        <p class="card-text small mb-1">
                            <i class="bi bi-collection"></i> В ${photo.inAlbums.length} альбомах
                        </p>
                    ` : ''}
                    ${photo.inCommercialPosts.length > 0 ? `
                        <p class="card-text small mb-0">
                            <i class="bi bi-megaphone"></i> В ${photo.inCommercialPosts.length} рекламе
                        </p>
                    ` : ''}
                </div>
            </div>
        `;
        
        gallery.appendChild(col);
        
        // Add event listeners
        const checkbox = col.querySelector('.photo-checkbox');
        checkbox.addEventListener('change', function() {
            if (this.checked) {
                selectedPhotos.add(photo.id);
            } else {
                selectedPhotos.delete(photo.id);
                document.getElementById('selectAll').checked = false;
            }
            updateSelectedCount();
        });
        
        // Delete button
        const deleteBtn = col.querySelector('.delete-photo-btn');
        deleteBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            deletePhoto(photo.id);
        });
        
        // Photo preview on image click
        const img = col.querySelector('.photo-thumbnail');
        img.addEventListener('click', function() {
            showPhotoPreview(photo);
        });
    });
}

function displayPagination(pagination) {
    const paginationEl = document.getElementById('pagination');
    paginationEl.innerHTML = '';
    
    if (pagination.lastPage <= 1) return;
    
    // Previous button
    const prevLi = document.createElement('li');
    prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
    prevLi.innerHTML = `<a class="page-link" href="#" data-page="${currentPage - 1}">Назад</a>`;
    paginationEl.appendChild(prevLi);
    
    // Page numbers
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(pagination.lastPage, currentPage + 2);
    
    if (startPage > 1) {
        const li = document.createElement('li');
        li.className = 'page-item';
        li.innerHTML = `<a class="page-link" href="#" data-page="1">1</a>`;
        paginationEl.appendChild(li);
        
        if (startPage > 2) {
            const li = document.createElement('li');
            li.className = 'page-item disabled';
            li.innerHTML = `<span class="page-link">...</span>`;
            paginationEl.appendChild(li);
        }
    }
    
    for (let i = startPage; i <= endPage; i++) {
        const li = document.createElement('li');
        li.className = `page-item ${i === currentPage ? 'active' : ''}`;
        li.innerHTML = `<a class="page-link" href="#" data-page="${i}">${i}</a>`;
        paginationEl.appendChild(li);
    }
    
    if (endPage < pagination.lastPage) {
        if (endPage < pagination.lastPage - 1) {
            const li = document.createElement('li');
            li.className = 'page-item disabled';
            li.innerHTML = `<span class="page-link">...</span>`;
            paginationEl.appendChild(li);
        }
        
        const li = document.createElement('li');
        li.className = 'page-item';
        li.innerHTML = `<a class="page-link" href="#" data-page="${pagination.lastPage}">${pagination.lastPage}</a>`;
        paginationEl.appendChild(li);
    }
    
    // Next button
    const nextLi = document.createElement('li');
    nextLi.className = `page-item ${currentPage === pagination.lastPage ? 'disabled' : ''}`;
    nextLi.innerHTML = `<a class="page-link" href="#" data-page="${currentPage + 1}">Вперед</a>`;
    paginationEl.appendChild(nextLi);
    
    // Add click handlers
    paginationEl.querySelectorAll('a.page-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = parseInt(this.dataset.page);
            if (page && page !== currentPage) {
                currentPage = page;
                selectedPhotos.clear();
                document.getElementById('selectAll').checked = false;
                updateSelectedCount();
                loadPhotos();
                window.scrollTo(0, 0);
            }
        });
    });
}

function deletePhoto(photoId) {
    Swal.fire({
        title: 'Подтверждение удаления',
        text: 'Вы уверены, что хотите удалить эту фотографию? Это действие нельзя отменить.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Да, удалить',
        cancelButtonText: 'Отмена'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('../api/moderation/delete_photo.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': window.csrfToken
                },
                body: JSON.stringify({ 
                    photoId: photoId,
                    csrf_token: window.csrfToken
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire('Удалено!', data.message, 'success');
                    selectedPhotos.delete(photoId);
                    updateSelectedCount();
                    loadPhotos();
                } else {
                    Swal.fire('Ошибка', data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error deleting photo:', error);
                Swal.fire('Ошибка', 'Не удалось удалить фотографию', 'error');
            });
        }
    });
}

function bulkDeletePhotos() {
    const photoIds = Array.from(selectedPhotos);
    
    fetch('../api/moderation/bulk_delete_photos.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': window.csrfToken
        },
        body: JSON.stringify({ 
            photoIds: photoIds,
            csrf_token: window.csrfToken
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire('Удалено!', data.message, 'success');
            selectedPhotos.clear();
            document.getElementById('selectAll').checked = false;
            updateSelectedCount();
            loadPhotos();
        } else {
            Swal.fire('Ошибка', data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error bulk deleting photos:', error);
        Swal.fire('Ошибка', 'Не удалось удалить фотографии', 'error');
    });
}

function showPhotoPreview(photo) {
    const modal = new bootstrap.Modal(document.getElementById('photoPreviewModal'));
    
    document.getElementById('photoPreviewTitle').textContent = photo.title || 'Без названия';
    document.getElementById('photoPreviewImage').src = photo.filePath;
    
    const infoHtml = `
        <div class="row">
            <div class="col-md-6">
                <p><strong>Автор:</strong> ${escapeHtml(photo.userName)}</p>
                <p><strong>Email:</strong> ${escapeHtml(photo.userEmail)}</p>
                ${photo.locationName ? `<p><strong>Локация:</strong> ${escapeHtml(photo.locationName)}</p>` : ''}
                <p><strong>Дата загрузки:</strong> ${formatDate(photo.createdAt)}</p>
            </div>
            <div class="col-md-6">
                ${photo.description ? `<p><strong>Описание:</strong> ${escapeHtml(photo.description)}</p>` : ''}
                ${photo.inAlbums.length > 0 ? `
                    <p><strong>В альбомах:</strong></p>
                    <ul>
                        ${photo.inAlbums.map(album => `<li>${escapeHtml(album)}</li>`).join('')}
                    </ul>
                ` : ''}
                ${photo.inCommercialPosts.length > 0 ? `
                    <p><strong>В рекламных постах:</strong></p>
                    <ul>
                        ${photo.inCommercialPosts.map(post => `<li>${escapeHtml(post)}</li>`).join('')}
                    </ul>
                ` : ''}
            </div>
        </div>
    `;
    
    document.getElementById('photoPreviewInfo').innerHTML = infoHtml;
    modal.show();
}

function updateSelectedCount() {
    document.getElementById('selectedCount').textContent = selectedPhotos.size;
    document.getElementById('bulkDeleteBtn').disabled = selectedPhotos.size === 0;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
