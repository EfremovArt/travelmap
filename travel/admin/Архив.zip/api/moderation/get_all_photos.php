<?php
require_once '../../config/admin_config.php';
require_once '../../../config.php';

adminRequireAuth();

header('Content-Type: application/json; charset=UTF-8');

try {
    $pdo = getDBConnection();
    
    // Get query parameters
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $perPage = isset($_GET['per_page']) ? max(1, min(100, intval($_GET['per_page']))) : 50;
    $userId = isset($_GET['user_id']) ? intval($_GET['user_id']) : null;
    $dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : null;
    $dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : null;
    $sortBy = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'created_at';
    $sortOrder = isset($_GET['sort_order']) && strtolower($_GET['sort_order']) === 'asc' ? 'ASC' : 'DESC';
    
    // Validate sort field
    $allowedSortFields = ['created_at', 'title', 'user_id'];
    if (!in_array($sortBy, $allowedSortFields)) {
        $sortBy = 'created_at';
    }
    
    $offset = ($page - 1) * $perPage;
    
    // Build WHERE clause
    $whereConditions = [];
    $params = [];
    
    if ($userId) {
        $whereConditions[] = 'p.user_id = :user_id';
        $params[':user_id'] = $userId;
    }
    
    if ($dateFrom) {
        $whereConditions[] = 'DATE(p.created_at) >= :date_from';
        $params[':date_from'] = $dateFrom;
    }
    
    if ($dateTo) {
        $whereConditions[] = 'DATE(p.created_at) <= :date_to';
        $params[':date_to'] = $dateTo;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // Get total count
    $countSql = "SELECT COUNT(*) as total FROM photos p $whereClause";
    $countStmt = $pdo->prepare($countSql);
    $countStmt->execute($params);
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Get photos with user and location info
    $sql = "SELECT 
                p.id,
                p.user_id,
                p.location_id,
                p.title,
                p.description,
                p.file_path,
                p.created_at,
                u.first_name,
                u.last_name,
                u.email,
                l.name as location_name
            FROM photos p
            LEFT JOIN users u ON p.user_id = u.id
            LEFT JOIN locations l ON p.location_id = l.id
            $whereClause
            ORDER BY p.$sortBy $sortOrder
            LIMIT :limit OFFSET :offset";
    
    $stmt = $pdo->prepare($sql);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $photos = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Get albums this photo is in
        $albumSql = "SELECT a.title 
                     FROM album_photos ap
                     JOIN albums a ON ap.album_id = a.id
                     WHERE ap.photo_id = :photo_id";
        $albumStmt = $pdo->prepare($albumSql);
        $albumStmt->execute([':photo_id' => $row['id']]);
        $albums = $albumStmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Get commercial posts this photo is in
        $commercialSql = "SELECT cp.title 
                          FROM commercial_posts cp
                          WHERE cp.photo_id = :photo_id";
        $commercialStmt = $pdo->prepare($commercialSql);
        $commercialStmt->execute([':photo_id' => $row['id']]);
        $commercialPosts = $commercialStmt->fetchAll(PDO::FETCH_COLUMN);
        
        $photos[] = [
            'id' => intval($row['id']),
            'userId' => intval($row['user_id']),
            'userName' => trim($row['first_name'] . ' ' . $row['last_name']),
            'userEmail' => $row['email'],
            'locationId' => $row['location_id'] ? intval($row['location_id']) : null,
            'locationName' => $row['location_name'],
            'title' => $row['title'],
            'description' => $row['description'],
            'filePath' => $row['file_path'],
            'createdAt' => $row['created_at'],
            'inAlbums' => $albums,
            'inCommercialPosts' => $commercialPosts
        ];
    }
    
    echo json_encode([
        'success' => true,
        'photos' => $photos,
        'pagination' => [
            'total' => intval($total),
            'perPage' => $perPage,
            'currentPage' => $page,
            'lastPage' => ceil($total / $perPage)
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Ошибка при получении фотографий: ' . $e->getMessage()
    ]);
}
