let postsTable, albumsTable, commercialTable;
let postsSearchTimeout, albumsSearchTimeout, commercialSearchTimeout;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Posts Table
    initPostsTable();
    
    // Initialize Albums Table
    initAlbumsTable();
    
    // Initialize Commercial Posts Table
    initCommercialTable();
    
    // Load users for filters
    loadUsersForFilters();
    
    // Search handlers
    document.getElementById('postsSearch').addEventListener('input', function() {
        clearTimeout(postsSearchTimeout);
        postsSearchTimeout = setTimeout(() => {
            postsTable.ajax.reload();
        }, 500);
    });
    
    document.getElementById('albumsSearch').addEventListener('input', function() {
        clearTimeout(albumsSearchTimeout);
        albumsSearchTimeout = setTimeout(() => {
            albumsTable.ajax.reload();
        }, 500);
    });
    
    document.getElementById('commercialSearch').addEventListener('input', function() {
        clearTimeout(commercialSearchTimeout);
        commercialSearchTimeout = setTimeout(() => {
            commercialTable.ajax.reload();
        }, 500);
    });
    
    // Filter handlers
    document.getElementById('postsUserFilter').addEventListener('change', function() {
        postsTable.ajax.reload();
    });
    
    document.getElementById('albumsUserFilter').addEventListener('change', function() {
        albumsTable.ajax.reload();
    });
    
    document.getElementById('commercialUserFilter').addEventListener('change', function() {
        commercialTable.ajax.reload();
    });
    
    document.getElementById('commercialTypeFilter').addEventListener('change', function() {
        commercialTable.ajax.reload();
    });
});

function initPostsTable() {
    postsTable = $('#postsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/posts/get_all_posts.php',
            type: 'GET',
            data: function(d) {
                return {
                    page: Math.floor(d.start / d.length) + 1,
                    per_page: d.length,
                    search: document.getElementById('postsSearch').value,
                    user_id: document.getElementById('postsUserFilter').value,
                    sort_by: 'created_at',
                    sort_order: 'desc'
                };
            },
            dataSrc: function(json) {
                if (json.success) {
                    json.recordsTotal = json.pagination.total;
                    json.recordsFiltered = json.pagination.total;
                    return json.posts;
                }
                return [];
            }
        },
        columns: [
            {
                data: 'preview',
                orderable: false,
                render: function(data, type, row) {
                    if (data) {
                        return `<img src="../../${data}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 4px;">`;
                    }
                    return '<div style="width: 60px; height: 60px; background: #ddd; border-radius: 4px;"></div>';
                }
            },
            {
                data: 'title',
                render: function(data, type, row) {
                    return `<div>
                        <strong>${escapeHtml(data || 'Без названия')}</strong>
                        ${row.description ? `<br><small class="text-muted">${escapeHtml(row.description.substring(0, 50))}${row.description.length > 50 ? '...' : ''}</small>` : ''}
                    </div>`;
                }
            },
            {
                data: 'user_name',
                render: function(data, type, row) {
                    return `<div class="d-flex align-items-center">
                        ${row.user_profile_image ? `<img src="../../${row.user_profile_image}" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">` : '<div class="rounded-circle bg-secondary me-2" style="width: 30px; height: 30px;"></div>'}
                        <div>
                            <div>${escapeHtml(data)}</div>
                            <small class="text-muted">${escapeHtml(row.user_email)}</small>
                        </div>
                    </div>`;
                }
            },
            {
                data: 'location_name',
                render: function(data) {
                    return data ? `<i class="fas fa-map-marker-alt me-1"></i>${escapeHtml(data)}` : '-';
                }
            },
            {
                data: 'likes_count',
                render: function(data) {
                    return `<span class="badge bg-danger">${data}</span>`;
                }
            },
            {
                data: 'comments_count',
                render: function(data) {
                    return `<span class="badge bg-info">${data}</span>`;
                }
            },
            {
                data: 'created_at',
                render: function(data) {
                    return formatDate(data);
                }
            }
        ],
        order: [[6, 'desc']],
        pageLength: 25,
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/ru.json'
        }
    });
}

function initAlbumsTable() {
    albumsTable = $('#albumsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/posts/get_all_albums.php',
            type: 'GET',
            data: function(d) {
                return {
                    page: Math.floor(d.start / d.length) + 1,
                    per_page: d.length,
                    search: document.getElementById('albumsSearch').value,
                    user_id: document.getElementById('albumsUserFilter').value,
                    sort_by: 'created_at',
                    sort_order: 'desc'
                };
            },
            dataSrc: function(json) {
                if (json.success) {
                    json.recordsTotal = json.pagination.total;
                    json.recordsFiltered = json.pagination.total;
                    return json.albums;
                }
                return [];
            }
        },
        columns: [
            {
                data: 'cover_photo',
                orderable: false,
                render: function(data) {
                    if (data) {
                        return `<img src="../../${data}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 4px;">`;
                    }
                    return '<div style="width: 60px; height: 60px; background: #ddd; border-radius: 4px;"></div>';
                }
            },
            {
                data: 'title',
                render: function(data, type, row) {
                    return `<div>
                        <strong>${escapeHtml(data)}</strong>
                        ${row.description ? `<br><small class="text-muted">${escapeHtml(row.description.substring(0, 50))}${row.description.length > 50 ? '...' : ''}</small>` : ''}
                    </div>`;
                }
            },
            {
                data: 'owner_name',
                render: function(data, type, row) {
                    return `<div class="d-flex align-items-center">
                        ${row.owner_profile_image ? `<img src="../../${row.owner_profile_image}" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">` : '<div class="rounded-circle bg-secondary me-2" style="width: 30px; height: 30px;"></div>'}
                        <div>
                            <div>${escapeHtml(data)}</div>
                            <small class="text-muted">${escapeHtml(row.owner_email)}</small>
                        </div>
                    </div>`;
                }
            },
            {
                data: 'photos_count',
                render: function(data) {
                    return `<span class="badge bg-primary">${data}</span>`;
                }
            },
            {
                data: 'is_public',
                render: function(data) {
                    return data == 1 ? '<span class="badge bg-success">Да</span>' : '<span class="badge bg-secondary">Нет</span>';
                }
            },
            {
                data: 'likes_count',
                render: function(data) {
                    return `<span class="badge bg-danger">${data}</span>`;
                }
            },
            {
                data: 'comments_count',
                render: function(data) {
                    return `<span class="badge bg-info">${data}</span>`;
                }
            },
            {
                data: 'favorites_count',
                render: function(data) {
                    return `<span class="badge bg-warning">${data}</span>`;
                }
            },
            {
                data: 'created_at',
                render: function(data) {
                    return formatDate(data);
                }
            },
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<button class="btn btn-sm btn-primary" onclick="viewAlbumPhotos(${row.id})">
                        <i class="fas fa-images"></i> Фото
                    </button>`;
                }
            }
        ],
        order: [[8, 'desc']],
        pageLength: 25,
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/ru.json'
        }
    });
}

function initCommercialTable() {
    commercialTable = $('#commercialTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/posts/get_all_commercial_posts.php',
            type: 'GET',
            data: function(d) {
                return {
                    page: Math.floor(d.start / d.length) + 1,
                    per_page: d.length,
                    search: document.getElementById('commercialSearch').value,
                    user_id: document.getElementById('commercialUserFilter').value,
                    type: document.getElementById('commercialTypeFilter').value,
                    sort_by: 'created_at',
                    sort_order: 'desc'
                };
            },
            dataSrc: function(json) {
                if (json.success) {
                    json.recordsTotal = json.pagination.total;
                    json.recordsFiltered = json.pagination.total;
                    return json.commercialPosts;
                }
                return [];
            }
        },
        columns: [
            {
                data: 'preview',
                orderable: false,
                render: function(data) {
                    if (data) {
                        return `<img src="../../${data}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 4px;">`;
                    }
                    return '<div style="width: 60px; height: 60px; background: #ddd; border-radius: 4px;"></div>';
                }
            },
            {
                data: 'title',
                render: function(data, type, row) {
                    return `<div>
                        <strong>${escapeHtml(data)}</strong>
                        ${row.description ? `<br><small class="text-muted">${escapeHtml(row.description.substring(0, 50))}${row.description.length > 50 ? '...' : ''}</small>` : ''}
                    </div>`;
                }
            },
            {
                data: 'user_name',
                render: function(data, type, row) {
                    return `<div class="d-flex align-items-center">
                        ${row.user_profile_image ? `<img src="../../${row.user_profile_image}" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">` : '<div class="rounded-circle bg-secondary me-2" style="width: 30px; height: 30px;"></div>'}
                        <div>
                            <div>${escapeHtml(data)}</div>
                            <small class="text-muted">${escapeHtml(row.user_email)}</small>
                        </div>
                    </div>`;
                }
            },
            {
                data: 'type',
                render: function(data) {
                    const types = {
                        'album': '<span class="badge bg-primary">Альбом</span>',
                        'photo': '<span class="badge bg-success">Фото</span>',
                        'standalone': '<span class="badge bg-info">Отдельный</span>'
                    };
                    return types[data] || data;
                }
            },
            {
                data: 'related_title',
                render: function(data) {
                    return data ? escapeHtml(data) : '-';
                }
            },
            {
                data: 'is_active',
                render: function(data) {
                    return data == 1 ? '<span class="badge bg-success">Активен</span>' : '<span class="badge bg-secondary">Неактивен</span>';
                }
            },
            {
                data: 'created_at',
                render: function(data) {
                    return formatDate(data);
                }
            },
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<button class="btn btn-sm btn-primary" onclick="viewCommercialPostDetails(${row.id})">
                        <i class="fas fa-eye"></i> Детали
                    </button>`;
                }
            }
        ],
        order: [[6, 'desc']],
        pageLength: 25,
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/ru.json'
        }
    });
}

function loadUsersForFilters() {
    fetch('../api/users/get_all_users.php?per_page=1000')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const users = data.users;
                const postsFilter = document.getElementById('postsUserFilter');
                const albumsFilter = document.getElementById('albumsUserFilter');
                const commercialFilter = document.getElementById('commercialUserFilter');
                
                users.forEach(user => {
                    const option = `<option value="${user.id}">${escapeHtml(user.first_name + ' ' + user.last_name)}</option>`;
                    postsFilter.innerHTML += option;
                    albumsFilter.innerHTML += option;
                    commercialFilter.innerHTML += option;
                });
            }
        })
        .catch(error => console.error('Error loading users:', error));
}

function viewAlbumPhotos(albumId) {
    const modal = new bootstrap.Modal(document.getElementById('albumPhotosModal'));
    const content = document.getElementById('albumPhotosContent');
    
    content.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"></div></div>';
    modal.show();
    
    fetch(`../api/posts/get_album_photos.php?album_id=${albumId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderAlbumPhotos(data);
            } else {
                content.innerHTML = `<div class="alert alert-danger">${escapeHtml(data.message)}</div>`;
            }
        })
        .catch(error => {
            content.innerHTML = '<div class="alert alert-danger">Ошибка при загрузке фотографий</div>';
            console.error(error);
        });
}

function renderAlbumPhotos(data) {
    const content = document.getElementById('albumPhotosContent');
    const album = data.album;
    const photos = data.photos;
    
    let html = `
        <div class="mb-4">
            <h5>${escapeHtml(album.title)}</h5>
            ${album.description ? `<p class="text-muted">${escapeHtml(album.description)}</p>` : ''}
            <p><strong>Владелец:</strong> ${escapeHtml(album.owner_name)}</p>
            <p><strong>Публичный:</strong> ${album.is_public == 1 ? 'Да' : 'Нет'}</p>
        </div>
        <div class="row">
    `;
    
    if (photos.length === 0) {
        html += '<div class="col-12"><p class="text-muted text-center">В альбоме нет фотографий</p></div>';
    } else {
        photos.forEach(photo => {
            html += `
                <div class="col-md-3 mb-3">
                    <div class="card">
                        <img src="../../${photo.file_path}" class="card-img-top" style="height: 150px; object-fit: cover;">
                        <div class="card-body p-2">
                            <p class="small mb-1"><strong>${escapeHtml(photo.title || 'Без названия')}</strong></p>
                            ${photo.location_name ? `<p class="text-muted small mb-0"><i class="fas fa-map-marker-alt me-1"></i>${escapeHtml(photo.location_name)}</p>` : ''}
                        </div>
                    </div>
                </div>
            `;
        });
    }
    
    html += '</div>';
    content.innerHTML = html;
}

function viewCommercialPostDetails(commercialPostId) {
    window.location.href = `commercial_post_details.php?id=${commercialPostId}`;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('ru-RU', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
