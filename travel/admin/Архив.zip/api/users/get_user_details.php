<?php
require_once '../../config/admin_config.php';
require_once '../../../config.php';

adminRequireAuth();

header('Content-Type: application/json; charset=UTF-8');

try {
    // Валидация параметра user_id
    $userId = validateInt(getParam('user_id'), 1);
    
    if ($userId === false) {
        adminHandleError('Неверный ID пользователя', 400, 'INVALID_PARAMETERS');
    }
    
    // Get user basic info
    $userSql = "SELECT id, first_name, last_name, email, profile_image, created_at FROM users WHERE id = :user_id";
    $userStmt = $pdo->prepare($userSql);
    $userStmt->execute([':user_id' => $userId]);
    $user = $userStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        throw new Exception('User not found');
    }
    
    // Get user statistics
    $statsSql = "
        SELECT 
            (SELECT COUNT(*) FROM follows WHERE followed_id = :user_id) as followers_count,
            (SELECT COUNT(*) FROM follows WHERE follower_id = :user_id) as following_count,
            (SELECT COUNT(*) FROM photos WHERE user_id = :user_id) as posts_count,
            (SELECT COUNT(*) FROM albums WHERE owner_id = :user_id) as albums_count,
            (SELECT COUNT(*) FROM commercial_posts WHERE user_id = :user_id) as commercial_posts_count,
            (SELECT COUNT(*) FROM likes WHERE user_id = :user_id) as likes_given,
            (SELECT COUNT(*) FROM likes l JOIN photos p ON l.photo_id = p.id WHERE p.user_id = :user_id) as likes_received,
            (SELECT COUNT(*) FROM comments WHERE user_id = :user_id) + 
            (SELECT COUNT(*) FROM album_comments WHERE user_id = :user_id) as comments_given,
            (SELECT COUNT(*) FROM comments c JOIN photos p ON c.photo_id = p.id WHERE p.user_id = :user_id) +
            (SELECT COUNT(*) FROM album_comments ac JOIN albums a ON ac.album_id = a.id WHERE a.owner_id = :user_id) as comments_received,
            (SELECT COUNT(*) FROM favorites WHERE user_id = :user_id) +
            (SELECT COUNT(*) FROM album_favorites WHERE user_id = :user_id) +
            (SELECT COUNT(*) FROM commercial_favorites WHERE user_id = :user_id) as favorites_count
    ";
    $statsStmt = $pdo->prepare($statsSql);
    $statsStmt->execute([':user_id' => $userId]);
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);
    
    // Get followers
    $followersSql = "
        SELECT u.id, u.first_name, u.last_name, u.email, u.profile_image, f.created_at
        FROM follows f
        JOIN users u ON f.follower_id = u.id
        WHERE f.followed_id = :user_id
        ORDER BY f.created_at DESC
        LIMIT 50
    ";
    $followersStmt = $pdo->prepare($followersSql);
    $followersStmt->execute([':user_id' => $userId]);
    $followers = $followersStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get following
    $followingSql = "
        SELECT u.id, u.first_name, u.last_name, u.email, u.profile_image, f.created_at
        FROM follows f
        JOIN users u ON f.followed_id = u.id
        WHERE f.follower_id = :user_id
        ORDER BY f.created_at DESC
        LIMIT 50
    ";
    $followingStmt = $pdo->prepare($followingSql);
    $followingStmt->execute([':user_id' => $userId]);
    $following = $followingStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get favorite posts
    $favoritePostsSql = "
        SELECT p.id, p.title, p.description, p.file_path, p.created_at, l.name as location_name, f.created_at as favorited_at
        FROM favorites f
        JOIN photos p ON f.photo_id = p.id
        LEFT JOIN locations l ON p.location_id = l.id
        WHERE f.user_id = :user_id
        ORDER BY f.created_at DESC
        LIMIT 50
    ";
    $favoritePostsStmt = $pdo->prepare($favoritePostsSql);
    $favoritePostsStmt->execute([':user_id' => $userId]);
    $favoritePosts = $favoritePostsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get favorite albums
    $favoriteAlbumsSql = "
        SELECT a.id, a.title, a.description, a.cover_photo_id, p.file_path as cover_photo, af.created_at as favorited_at
        FROM album_favorites af
        JOIN albums a ON af.album_id = a.id
        LEFT JOIN album_photos p ON a.cover_photo_id = p.id
        WHERE af.user_id = :user_id
        ORDER BY af.created_at DESC
        LIMIT 50
    ";
    $favoriteAlbumsStmt = $pdo->prepare($favoriteAlbumsSql);
    $favoriteAlbumsStmt->execute([':user_id' => $userId]);
    $favoriteAlbums = $favoriteAlbumsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get commented posts
    $commentedPostsSql = "
        SELECT DISTINCT p.id, p.title, p.description, p.file_path, p.created_at, l.name as location_name,
               (SELECT COUNT(*) FROM comments WHERE photo_id = p.id AND user_id = :user_id) as comment_count
        FROM comments c
        JOIN photos p ON c.photo_id = p.id
        LEFT JOIN locations l ON p.location_id = l.id
        WHERE c.user_id = :user_id
        ORDER BY c.created_at DESC
        LIMIT 50
    ";
    $commentedPostsStmt = $pdo->prepare($commentedPostsSql);
    $commentedPostsStmt->execute([':user_id' => $userId]);
    $commentedPosts = $commentedPostsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get posts with comments (posts owned by user that have comments)
    $postsWithCommentsSql = "
        SELECT DISTINCT p.id, p.title, p.description, p.file_path, p.created_at, l.name as location_name,
               (SELECT COUNT(*) FROM comments WHERE photo_id = p.id) as comment_count
        FROM photos p
        LEFT JOIN locations l ON p.location_id = l.id
        WHERE p.user_id = :user_id AND EXISTS (SELECT 1 FROM comments WHERE photo_id = p.id)
        ORDER BY p.created_at DESC
        LIMIT 50
    ";
    $postsWithCommentsStmt = $pdo->prepare($postsWithCommentsSql);
    $postsWithCommentsStmt->execute([':user_id' => $userId]);
    $postsWithComments = $postsWithCommentsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format response
    $response = [
        'success' => true,
        'user' => [
            'id' => intval($user['id']),
            'firstName' => $user['first_name'],
            'lastName' => $user['last_name'],
            'email' => $user['email'],
            'profileImage' => $user['profile_image'],
            'createdAt' => $user['created_at']
        ],
        'stats' => [
            'followersCount' => intval($stats['followers_count']),
            'followingCount' => intval($stats['following_count']),
            'postsCount' => intval($stats['posts_count']),
            'albumsCount' => intval($stats['albums_count']),
            'commercialPostsCount' => intval($stats['commercial_posts_count']),
            'likesGiven' => intval($stats['likes_given']),
            'likesReceived' => intval($stats['likes_received']),
            'commentsGiven' => intval($stats['comments_given']),
            'commentsReceived' => intval($stats['comments_received']),
            'favoritesCount' => intval($stats['favorites_count'])
        ],
        'followers' => array_map(function($f) {
            return [
                'id' => intval($f['id']),
                'firstName' => $f['first_name'],
                'lastName' => $f['last_name'],
                'email' => $f['email'],
                'profileImage' => $f['profile_image'],
                'followedAt' => $f['created_at']
            ];
        }, $followers),
        'following' => array_map(function($f) {
            return [
                'id' => intval($f['id']),
                'firstName' => $f['first_name'],
                'lastName' => $f['last_name'],
                'email' => $f['email'],
                'profileImage' => $f['profile_image'],
                'followedAt' => $f['created_at']
            ];
        }, $following),
        'favoritePosts' => array_map(function($p) {
            return [
                'id' => intval($p['id']),
                'title' => $p['title'],
                'description' => $p['description'],
                'filePath' => $p['file_path'],
                'locationName' => $p['location_name'],
                'createdAt' => $p['created_at'],
                'favoritedAt' => $p['favorited_at']
            ];
        }, $favoritePosts),
        'favoriteAlbums' => array_map(function($a) {
            return [
                'id' => intval($a['id']),
                'title' => $a['title'],
                'description' => $a['description'],
                'coverPhoto' => $a['cover_photo'],
                'favoritedAt' => $a['favorited_at']
            ];
        }, $favoriteAlbums),
        'commentedPosts' => array_map(function($p) {
            return [
                'id' => intval($p['id']),
                'title' => $p['title'],
                'description' => $p['description'],
                'filePath' => $p['file_path'],
                'locationName' => $p['location_name'],
                'createdAt' => $p['created_at'],
                'commentCount' => intval($p['comment_count'])
            ];
        }, $commentedPosts),
        'postsWithComments' => array_map(function($p) {
            return [
                'id' => intval($p['id']),
                'title' => $p['title'],
                'description' => $p['description'],
                'filePath' => $p['file_path'],
                'locationName' => $p['location_name'],
                'createdAt' => $p['created_at'],
                'commentCount' => intval($p['comment_count'])
            ];
        }, $postsWithComments)
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Ошибка при получении данных пользователя: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
