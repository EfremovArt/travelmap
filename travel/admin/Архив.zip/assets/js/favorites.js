$(document).ready(function() {
    let currentType = 'all';
    let tables = {};
    
    // Initialize DataTable for a specific type
    function initDataTable(type, tableId, filters = {}) {
        if (tables[type]) {
            tables[type].destroy();
        }
        
        const columns = getColumnsForType(type);
        
        tables[type] = $(tableId).DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '../api/favorites/get_all_favorites.php',
                type: 'GET',
                data: function(d) {
                    // Map DataTables parameters to our API
                    return {
                        page: Math.floor(d.start / d.length) + 1,
                        per_page: d.length,
                        search: d.search.value,
                        sort_by: getSortColumn(d.order[0].column, type),
                        sort_order: d.order[0].dir,
                        type: type,
                        user_id: filters.user_id || '',
                    };
                },
                dataSrc: function(json) {
                    if (!json.success) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Ошибка',
                            text: json.message || 'Не удалось загрузить данные'
                        });
                        return [];
                    }
                    
                    // Set total records for pagination
                    json.recordsTotal = json.pagination.total;
                    json.recordsFiltered = json.pagination.total;
                    
                    return json.favorites;
                },
                error: function(xhr, error, thrown) {
                    console.error('DataTables error:', error, thrown);
                    Swal.fire({
                        icon: 'error',
                        title: 'Ошибка загрузки',
                        text: 'Не удалось загрузить данные. Проверьте консоль для деталей.'
                    });
                }
            },
            columns: columns,
            order: getDefaultOrder(type),
            pageLength: 50,
            lengthMenu: [[25, 50, 100], [25, 50, 100]],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/ru.json'
            },
            dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rtip'
        });
    }
    
    // Get columns configuration based on type
    function getColumnsForType(type) {
        const baseColumns = [
            { 
                data: 'id',
                width: '50px'
            },
            { 
                data: null,
                render: function(data, type, row) {
                    let img = row.userImage ? 
                        `<img src="../../../${row.userImage}" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;">` :
                        `<div class="rounded-circle bg-secondary d-inline-block me-2" style="width: 30px; height: 30px;"></div>`;
                    return img + escapeHtml(row.userName);
                },
                orderable: true
            }
        ];
        
        if (type === 'all') {
            return [
                ...baseColumns,
                {
                    data: 'contentType',
                    render: function(data) {
                        const typeLabels = {
                            'photo': '<span class="badge bg-primary">Фото</span>',
                            'album': '<span class="badge bg-success">Альбом</span>',
                            'commercial': '<span class="badge bg-warning text-dark">Коммерческий</span>'
                        };
                        return typeLabels[data] || data;
                    },
                    orderable: false
                },
                {
                    data: 'contentTitle',
                    render: function(data, type, row) {
                        return `<a href="#" class="text-decoration-none" onclick="viewContent('${row.contentType}', ${row.contentId}); return false;">
                                    ${escapeHtml(data || 'Без названия')}
                                </a>`;
                    },
                    orderable: true
                },
                {
                    data: 'locationName',
                    render: function(data) {
                        return escapeHtml(data || 'Не указана');
                    }
                },
                {
                    data: 'createdAt',
                    render: function(data) {
                        return formatDateTime(data);
                    },
                    orderable: true
                },
                {
                    data: 'contentPreview',
                    render: function(data, type, row) {
                        if (data) {
                            const imagePath = data.startsWith('/') ? `../../..${data}` : `../../../${data}`;
                            return `<img src="${imagePath}" class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover; cursor: pointer;" 
                                    onclick="showImagePreview('${imagePath}')" 
                                    title="Нажмите для увеличения">`;
                        }
                        return '<span class="text-muted">Нет изображения</span>';
                    },
                    orderable: false
                }
            ];
        } else if (type === 'photo') {
            return [
                ...baseColumns,
                {
                    data: 'contentTitle',
                    render: function(data, type, row) {
                        return `<a href="#" class="text-decoration-none" onclick="viewContent('photo', ${row.contentId}); return false;">
                                    ${escapeHtml(data || 'Без названия')}
                                </a>`;
                    },
                    orderable: true
                },
                {
                    data: 'locationName',
                    render: function(data) {
                        return escapeHtml(data || 'Не указана');
                    }
                },
                {
                    data: 'createdAt',
                    render: function(data) {
                        return formatDateTime(data);
                    },
                    orderable: true
                },
                {
                    data: 'contentPreview',
                    render: function(data) {
                        if (data) {
                            const imagePath = data.startsWith('/') ? `../../..${data}` : `../../../${data}`;
                            return `<img src="${imagePath}" class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover; cursor: pointer;" 
                                    onclick="showImagePreview('${imagePath}')" 
                                    title="Нажмите для увеличения">`;
                        }
                        return '<span class="text-muted">Нет изображения</span>';
                    },
                    orderable: false
                }
            ];
        } else if (type === 'album') {
            return [
                ...baseColumns,
                {
                    data: 'contentTitle',
                    render: function(data, type, row) {
                        return `<a href="#" class="text-decoration-none" onclick="viewContent('album', ${row.contentId}); return false;">
                                    ${escapeHtml(data || 'Без названия')}
                                </a>`;
                    },
                    orderable: true
                },
                {
                    data: 'createdAt',
                    render: function(data) {
                        return formatDateTime(data);
                    },
                    orderable: true
                },
                {
                    data: 'contentPreview',
                    render: function(data) {
                        if (data) {
                            const imagePath = data.startsWith('/') ? `../../..${data}` : `../../../${data}`;
                            return `<img src="${imagePath}" class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover; cursor: pointer;" 
                                    onclick="showImagePreview('${imagePath}')" 
                                    title="Нажмите для увеличения">`;
                        }
                        return '<span class="text-muted">Нет изображения</span>';
                    },
                    orderable: false
                }
            ];
        } else if (type === 'commercial') {
            return [
                ...baseColumns,
                {
                    data: 'contentTitle',
                    render: function(data, type, row) {
                        return `<a href="#" class="text-decoration-none" onclick="viewContent('commercial', ${row.contentId}); return false;">
                                    ${escapeHtml(data || 'Без названия')}
                                </a>`;
                    },
                    orderable: true
                },
                {
                    data: 'locationName',
                    render: function(data) {
                        return escapeHtml(data || 'Не указана');
                    }
                },
                {
                    data: 'createdAt',
                    render: function(data) {
                        return formatDateTime(data);
                    },
                    orderable: true
                },
                {
                    data: 'contentPreview',
                    render: function(data) {
                        if (data) {
                            const imagePath = data.startsWith('/') ? `../../..${data}` : `../../../${data}`;
                            return `<img src="${imagePath}" class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover; cursor: pointer;" 
                                    onclick="showImagePreview('${imagePath}')" 
                                    title="Нажмите для увеличения">`;
                        }
                        return '<span class="text-muted">Нет изображения</span>';
                    },
                    orderable: false
                }
            ];
        }
    }
    
    // Get default order based on type
    function getDefaultOrder(type) {
        if (type === 'all') {
            return [[5, 'desc']]; // Sort by created_at
        } else if (type === 'album') {
            return [[3, 'desc']]; // Sort by created_at
        } else {
            return [[4, 'desc']]; // Sort by created_at
        }
    }
    
    // Get sort column name
    function getSortColumn(columnIndex, type) {
        if (type === 'all') {
            const columns = ['id', 'user_name', 'contentType', 'content_title', 'locationName', 'created_at', 'contentPreview'];
            return columns[columnIndex] || 'created_at';
        } else if (type === 'album') {
            const columns = ['id', 'user_name', 'content_title', 'created_at', 'contentPreview'];
            return columns[columnIndex] || 'created_at';
        } else {
            const columns = ['id', 'user_name', 'content_title', 'locationName', 'created_at', 'contentPreview'];
            return columns[columnIndex] || 'created_at';
        }
    }
    
    // Initialize all tables on page load
    initDataTable('all', '#favoritesTable');
    
    // Handle tab switching
    $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function (e) {
        const type = $(e.target).data('type');
        currentType = type;
        
        // Update type filter select
        $('#typeFilter').val(type);
        
        // Initialize table for this type if not already initialized
        const tableId = type === 'all' ? '#favoritesTable' : 
                       type === 'photo' ? '#photoFavoritesTable' :
                       type === 'album' ? '#albumFavoritesTable' :
                       '#commercialFavoritesTable';
        
        if (!tables[type]) {
            const filters = {
                user_id: $('#userFilter').val()
            };
            initDataTable(type, tableId, filters);
        }
    });
    
    // Handle filter form submission
    $('#filterForm').on('submit', function(e) {
        e.preventDefault();
        
        const selectedType = $('#typeFilter').val();
        const filters = {
            user_id: $('#userFilter').val()
        };
        
        // Switch to the selected tab
        if (selectedType !== currentType) {
            $(`button[data-type="${selectedType}"]`).tab('show');
        }
        
        // Reload the current table
        const tableId = selectedType === 'all' ? '#favoritesTable' : 
                       selectedType === 'photo' ? '#photoFavoritesTable' :
                       selectedType === 'album' ? '#albumFavoritesTable' :
                       '#commercialFavoritesTable';
        
        initDataTable(selectedType, tableId, filters);
    });
    
    // Handle reset filters
    $('#resetFilters').on('click', function() {
        $('#filterForm')[0].reset();
        $('#typeFilter').val('all');
        $('button[data-type="all"]').tab('show');
        initDataTable('all', '#favoritesTable');
    });
    
    // View content details (placeholder function)
    window.viewContent = function(contentType, contentId) {
        Swal.fire({
            title: 'Просмотр контента',
            html: `Тип: ${contentType}<br>ID: ${contentId}`,
            icon: 'info'
        });
    };
    
    // Show image preview
    window.showImagePreview = function(imagePath) {
        Swal.fire({
            imageUrl: imagePath,
            imageAlt: 'Превью изображения',
            showCloseButton: true,
            showConfirmButton: false,
            width: 'auto',
            customClass: {
                image: 'img-fluid'
            }
        });
    };
    
    // Escape HTML to prevent XSS
    function escapeHtml(text) {
        if (!text) return '';
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.toString().replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
    // Format datetime
    function formatDateTime(datetime) {
        if (!datetime) return '';
        const date = new Date(datetime);
        return date.toLocaleString('ru-RU', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
});
