            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" href="/travel/admin/index.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                                <span>Контент</span>
                            </h6>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo in_array(basename($_SERVER['PHP_SELF']), ['posts.php', 'commercial_post_details.php']) ? 'active' : ''; ?>" href="/travel/admin/views/posts.php">
                                <i class="fas fa-images"></i> Публикации
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'moderation.php' ? 'active' : ''; ?>" href="/travel/admin/views/moderation.php">
                                <i class="fas fa-shield-alt"></i> Модерация
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                                <span>Пользователи</span>
                            </h6>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>" href="/travel/admin/views/users.php">
                                <i class="fas fa-users"></i> Пользователи
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'follows.php' ? 'active' : ''; ?>" href="/travel/admin/views/follows.php">
                                <i class="fas fa-user-friends"></i> Подписки
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                                <span>Активность</span>
                            </h6>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'likes.php' ? 'active' : ''; ?>" href="/travel/admin/views/likes.php">
                                <i class="fas fa-heart"></i> Лайки
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'comments.php' ? 'active' : ''; ?>" href="/travel/admin/views/comments.php">
                                <i class="fas fa-comments"></i> Комментарии
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'favorites.php' ? 'active' : ''; ?>" href="/travel/admin/views/favorites.php">
                                <i class="fas fa-star"></i> Избранное
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
