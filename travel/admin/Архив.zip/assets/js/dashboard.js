// Dashboard JavaScript
let activityChart = null;

// Load dashboard statistics
async function loadDashboardStats() {
    try {
        const response = await fetch('../api/dashboard/get_stats.php');
        const data = await response.json();
        
        if (data.success) {
            const stats = data.stats;
            
            // Update stat cards
            document.getElementById('totalUsers').textContent = stats.totalUsers.toLocaleString();
            document.getElementById('totalPosts').textContent = stats.totalPosts.toLocaleString();
            document.getElementById('totalLikes').textContent = stats.totalLikes.toLocaleString();
            document.getElementById('totalComments').textContent = stats.totalComments.toLocaleString();
            document.getElementById('totalFollows').textContent = stats.totalFollows.toLocaleString();
            document.getElementById('totalFavorites').textContent = stats.totalFavorites.toLocaleString();
            document.getElementById('totalAlbums').textContent = stats.totalAlbums.toLocaleString();
            document.getElementById('totalCommercialPosts').textContent = stats.totalCommercialPosts.toLocaleString();
            
            // Update recent activity
            document.getElementById('newUsers').textContent = stats.recentActivity.newUsers.toLocaleString();
            document.getElementById('newPosts').textContent = stats.recentActivity.newPosts.toLocaleString();
            document.getElementById('newComments').textContent = stats.recentActivity.newComments.toLocaleString();
            
            // Create activity chart
            createActivityChart(stats.activityData);
        } else {
            console.error('Error loading stats:', data.message);
            showError('Ошибка загрузки статистики');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('Ошибка при загрузке данных');
    }
}

// Create activity chart using Chart.js
function createActivityChart(activityData) {
    const ctx = document.getElementById('activityChart');
    
    // Destroy existing chart if it exists
    if (activityChart) {
        activityChart.destroy();
    }
    
    const labels = activityData.map(item => item.date);
    const usersData = activityData.map(item => item.users);
    const postsData = activityData.map(item => item.posts);
    const commentsData = activityData.map(item => item.comments);
    
    activityChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Новые пользователи',
                    data: usersData,
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    tension: 0.1
                },
                {
                    label: 'Новые посты',
                    data: postsData,
                    borderColor: 'rgb(54, 162, 235)',
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    tension: 0.1
                },
                {
                    label: 'Новые комментарии',
                    data: commentsData,
                    borderColor: 'rgb(255, 206, 86)',
                    backgroundColor: 'rgba(255, 206, 86, 0.2)',
                    tension: 0.1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// Show error message
function showError(message) {
    const statsCards = document.getElementById('statsCards');
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-danger alert-dismissible fade show';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    statsCards.parentNode.insertBefore(alertDiv, statsCards);
}

// Initialize dashboard on page load
document.addEventListener('DOMContentLoaded', function() {
    loadDashboardStats();
});
