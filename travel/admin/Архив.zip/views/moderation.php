<?php
require_once __DIR__ . '/../config/admin_config.php';
adminRequireAuth();

$pageTitle = 'Модерация контента';
?>
<?php include __DIR__ . '/../includes/header.php'; ?>
<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<div id="content">
    <div class="page-header">
        <h1><i class="bi bi-shield-check"></i> Модерация контента</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index.php">Главная</a></li>
                <li class="breadcrumb-item active" aria-current="page">Модерация</li>
            </ol>
        </nav>
        <div class="page-actions">
            <button type="button" class="btn btn-danger" id="bulkDeleteBtn" disabled>
                <i class="bi bi-trash"></i> Удалить выбранные (<span id="selectedCount">0</span>)
            </button>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="bi bi-funnel"></i> Фильтры
        </div>
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <label for="filterUser" class="form-label">Пользователь</label>
                    <input type="number" class="form-control" id="filterUser" placeholder="ID пользователя">
                </div>
                <div class="col-md-3">
                    <label for="filterDateFrom" class="form-label">Дата от</label>
                    <input type="date" class="form-control" id="filterDateFrom">
                </div>
                <div class="col-md-3">
                    <label for="filterDateTo" class="form-label">Дата до</label>
                    <input type="date" class="form-control" id="filterDateTo">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">Применить</button>
                    <button type="button" class="btn btn-secondary" id="resetFilters">Сбросить</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Photo Gallery -->
    <div class="card">
        <div class="card-header">
            <i class="bi bi-images"></i> Галерея фотографий
        </div>
        <div class="card-body">
            <div class="mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="selectAll">
                    <label class="form-check-label" for="selectAll">
                        Выбрать все на странице
                    </label>
                </div>
            </div>
            
            <div id="photoGallery" class="row g-3">
                <!-- Photos will be loaded here -->
            </div>
            
            <div id="loadingSpinner" class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Загрузка...</span>
                </div>
            </div>
            
            <div id="noPhotos" class="text-center py-5" style="display: none;">
                <p class="text-muted">Фотографии не найдены</p>
            </div>
            
            <!-- Pagination -->
            <nav aria-label="Photo pagination" class="mt-4">
                <ul class="pagination justify-content-center" id="pagination">
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Photo Preview Modal -->
<div class="modal fade" id="photoPreviewModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="photoPreviewTitle">Просмотр фотографии</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="photoPreviewImage" src="" alt="Photo preview" class="img-fluid" style="max-height: 70vh;">
                <div id="photoPreviewInfo" class="mt-3 text-start">
                    <!-- Photo info will be loaded here -->
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/moderation.js"></script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
