<?php
require_once '../config/admin_config.php';
adminRequireAuth();

$pageTitle = 'Управление публикациями';
include '../includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-images me-2"></i>Управление публикациями</h2>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4" id="postsTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="posts-tab" data-bs-toggle="tab" data-bs-target="#posts" type="button" role="tab">
                <i class="fas fa-image me-2"></i>Посты
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="albums-tab" data-bs-toggle="tab" data-bs-target="#albums" type="button" role="tab">
                <i class="fas fa-folder me-2"></i>Альбомы
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="commercial-tab" data-bs-toggle="tab" data-bs-target="#commercial" type="button" role="tab">
                <i class="fas fa-ad me-2"></i>Коммерческие посты
            </button>
        </li>
    </ul>

    <!-- Tab Content -->
    <div class="tab-content" id="postsTabContent">
        <!-- Posts Tab -->
        <div class="tab-pane fade show active" id="posts" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-4">
                            <input type="text" class="form-control" id="postsSearch" placeholder="Поиск по заголовку или локации...">
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" id="postsUserFilter">
                                <option value="">Все пользователи</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="postsTable">
                            <thead>
                                <tr>
                                    <th>Превью</th>
                                    <th>Заголовок</th>
                                    <th>Автор</th>
                                    <th>Локация</th>
                                    <th>Лайки</th>
                                    <th>Комментарии</th>
                                    <th>Дата создания</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Albums Tab -->
        <div class="tab-pane fade" id="albums" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-4">
                            <input type="text" class="form-control" id="albumsSearch" placeholder="Поиск по названию...">
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" id="albumsUserFilter">
                                <option value="">Все пользователи</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="albumsTable">
                            <thead>
                                <tr>
                                    <th>Обложка</th>
                                    <th>Название</th>
                                    <th>Владелец</th>
                                    <th>Фото</th>
                                    <th>Публичный</th>
                                    <th>Лайки</th>
                                    <th>Комментарии</th>
                                    <th>Избранное</th>
                                    <th>Дата создания</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Commercial Posts Tab -->
        <div class="tab-pane fade" id="commercial" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-3">
                            <input type="text" class="form-control" id="commercialSearch" placeholder="Поиск...">
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" id="commercialUserFilter">
                                <option value="">Все пользователи</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select class="form-select" id="commercialTypeFilter">
                                <option value="">Все типы</option>
                                <option value="album">Альбом</option>
                                <option value="photo">Фото</option>
                                <option value="standalone">Отдельный</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="commercialTable">
                            <thead>
                                <tr>
                                    <th>Превью</th>
                                    <th>Заголовок</th>
                                    <th>Автор</th>
                                    <th>Тип</th>
                                    <th>Связь</th>
                                    <th>Статус</th>
                                    <th>Дата создания</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Album Photos Modal -->
<div class="modal fade" id="albumPhotosModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Фотографии альбома</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="albumPhotosContent">
                    <div class="text-center">
                        <div class="spinner-border" role="status"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script src="../assets/js/posts.js"></script>
