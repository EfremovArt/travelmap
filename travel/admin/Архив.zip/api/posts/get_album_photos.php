<?php
require_once '../../config/admin_config.php';
require_once '../../../config.php';

adminRequireAuth();

header('Content-Type: application/json; charset=UTF-8');

try {
    $albumId = isset($_GET['album_id']) ? intval($_GET['album_id']) : 0;
    
    if (!$albumId) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Не указан ID альбома'
        ]);
        exit;
    }
    
    // Get album info
    $albumSql = "SELECT 
                    a.id,
                    a.title,
                    a.description,
                    a.owner_id,
                    CONCAT(u.first_name, ' ', u.last_name) as owner_name,
                    a.is_public,
                    a.created_at
                 FROM albums a
                 LEFT JOIN users u ON a.owner_id = u.id
                 WHERE a.id = :album_id";
    
    $albumStmt = $pdo->prepare($albumSql);
    $albumStmt->execute([':album_id' => $albumId]);
    $album = $albumStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$album) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'Альбом не найден'
        ]);
        exit;
    }
    
    // Get album photos
    $photosSql = "SELECT 
                    ap.id,
                    ap.album_id,
                    ap.photo_id,
                    ap.file_path,
                    ap.title,
                    ap.description,
                    ap.position,
                    ap.created_at,
                    p.location_id,
                    l.name as location_name
                  FROM album_photos ap
                  LEFT JOIN photos p ON ap.photo_id = p.id
                  LEFT JOIN locations l ON p.location_id = l.id
                  WHERE ap.album_id = :album_id
                  ORDER BY ap.position ASC, ap.created_at ASC";
    
    $photosStmt = $pdo->prepare($photosSql);
    $photosStmt->execute([':album_id' => $albumId]);
    $photos = $photosStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'album' => $album,
        'photos' => $photos
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Ошибка при получении фотографий альбома: ' . $e->getMessage()
    ]);
}
