<?php
require_once '../../config/admin_config.php';
require_once '../../../config.php';

adminRequireAuth();

header('Content-Type: application/json; charset=UTF-8');

try {
    $commercialPostId = isset($_GET['commercial_post_id']) ? intval($_GET['commercial_post_id']) : 0;
    
    if (!$commercialPostId) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Не указан ID коммерческого поста'
        ]);
        exit;
    }
    
    // Get commercial post info
    $cpSql = "SELECT 
                cp.id,
                cp.title,
                cp.description,
                cp.type,
                cp.album_id,
                cp.photo_id,
                cp.user_id,
                CONCAT(u.first_name, ' ', u.last_name) as user_name,
                cp.latitude,
                cp.longitude,
                cp.is_active,
                cp.created_at
              FROM commercial_posts cp
              LEFT JOIN users u ON cp.user_id = u.id
              WHERE cp.id = :commercial_post_id";
    
    $cpStmt = $pdo->prepare($cpSql);
    $cpStmt->execute([':commercial_post_id' => $commercialPostId]);
    $commercialPost = $cpStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$commercialPost) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'Коммерческий пост не найден'
        ]);
        exit;
    }
    
    $relatedAlbums = [];
    $relatedPhotos = [];
    
    // Get related albums if type is 'album'
    if ($commercialPost['type'] === 'album' && $commercialPost['album_id']) {
        $albumSql = "SELECT 
                        a.id,
                        a.title,
                        a.description,
                        ac.file_path as cover_photo,
                        (SELECT COUNT(*) FROM album_photos WHERE album_id = a.id) as photos_count
                     FROM albums a
                     LEFT JOIN album_covers ac ON a.cover_photo_id = ac.id
                     WHERE a.id = :album_id";
        
        $albumStmt = $pdo->prepare($albumSql);
        $albumStmt->execute([':album_id' => $commercialPost['album_id']]);
        $album = $albumStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($album) {
            $relatedAlbums[] = $album;
            
            // Get photos in the album
            $albumPhotosSql = "SELECT 
                                ap.id,
                                ap.photo_id,
                                ap.title,
                                ap.file_path as preview,
                                p.location_id,
                                l.name as location_name
                               FROM album_photos ap
                               LEFT JOIN photos p ON ap.photo_id = p.id
                               LEFT JOIN locations l ON p.location_id = l.id
                               WHERE ap.album_id = :album_id
                               ORDER BY ap.position ASC
                               LIMIT 10";
            
            $albumPhotosStmt = $pdo->prepare($albumPhotosSql);
            $albumPhotosStmt->execute([':album_id' => $commercialPost['album_id']]);
            $relatedPhotos = $albumPhotosStmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    
    // Get related photo if type is 'photo'
    if ($commercialPost['type'] === 'photo' && $commercialPost['photo_id']) {
        $photoSql = "SELECT 
                        p.id,
                        p.title,
                        p.description,
                        p.file_path as preview,
                        p.location_id,
                        l.name as location_name,
                        l.latitude,
                        l.longitude
                     FROM photos p
                     LEFT JOIN locations l ON p.location_id = l.id
                     WHERE p.id = :photo_id";
        
        $photoStmt = $pdo->prepare($photoSql);
        $photoStmt->execute([':photo_id' => $commercialPost['photo_id']]);
        $photo = $photoStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($photo) {
            $relatedPhotos[] = $photo;
        }
    }
    
    // Get all photos where this commercial post is displayed
    $displayedInSql = "SELECT 
                        p.id,
                        p.title,
                        p.file_path as preview,
                        p.location_id,
                        l.name as location_name
                       FROM photo_commercial_posts pcp
                       INNER JOIN photos p ON pcp.photo_id = p.id
                       LEFT JOIN locations l ON p.location_id = l.id
                       WHERE pcp.commercial_post_id = :commercial_post_id";
    
    $displayedInStmt = $pdo->prepare($displayedInSql);
    $displayedInStmt->execute([':commercial_post_id' => $commercialPostId]);
    $displayedInPhotos = $displayedInStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'commercialPost' => $commercialPost,
        'relatedAlbums' => $relatedAlbums,
        'relatedPhotos' => $relatedPhotos,
        'displayedInPhotos' => $displayedInPhotos
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Ошибка при получении связей коммерческого поста: ' . $e->getMessage()
    ]);
}
