-- Создание таблицы для администраторов
CREATE TABLE IF NOT EXISTS admin_users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login TIMESTAMP NULL,
  INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Создание тестового администратора
-- Имя пользователя: admin
-- Пароль: admin123
-- ВАЖНО: Измените пароль после первого входа!
INSERT INTO admin_users (username, password_hash, email) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@travelmap.com')
ON DUPLICATE KEY UPDATE username = username;

-- Примечание: Хеш пароля создан с помощью password_hash('admin123', PASSWORD_DEFAULT)
-- Для создания нового администратора используйте PHP:
-- $hash = password_hash('your_password', PASSWORD_DEFAULT);
-- INSERT INTO admin_users (username, password_hash, email) VALUES ('username', '$hash', 'email@example.com');
