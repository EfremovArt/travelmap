-- Performance Optimization Indexes for Admin Panel
-- Run this migration to add indexes for faster query performance

-- Indexes for likes table
CREATE INDEX IF NOT EXISTS idx_likes_user_id ON likes(user_id);
CREATE INDEX IF NOT EXISTS idx_likes_photo_id ON likes(photo_id);
CREATE INDEX IF NOT EXISTS idx_likes_created_at ON likes(created_at);

-- Indexes for comments table
CREATE INDEX IF NOT EXISTS idx_comments_user_id ON comments(user_id);
CREATE INDEX IF NOT EXISTS idx_comments_photo_id ON comments(photo_id);
CREATE INDEX IF NOT EXISTS idx_comments_created_at ON comments(created_at);

-- Indexes for album_comments table
CREATE INDEX IF NOT EXISTS idx_album_comments_user_id ON album_comments(user_id);
CREATE INDEX IF NOT EXISTS idx_album_comments_album_id ON album_comments(album_id);
CREATE INDEX IF NOT EXISTS idx_album_comments_created_at ON album_comments(created_at);

-- Indexes for follows table
CREATE INDEX IF NOT EXISTS idx_follows_follower_id ON follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_followed_id ON follows(followed_id);
CREATE INDEX IF NOT EXISTS idx_follows_created_at ON follows(created_at);

-- Indexes for favorites table
CREATE INDEX IF NOT EXISTS idx_favorites_user_id ON favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_favorites_photo_id ON favorites(photo_id);
CREATE INDEX IF NOT EXISTS idx_favorites_created_at ON favorites(created_at);

-- Indexes for album_favorites table
CREATE INDEX IF NOT EXISTS idx_album_favorites_user_id ON album_favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_album_favorites_album_id ON album_favorites(album_id);
CREATE INDEX IF NOT EXISTS idx_album_favorites_created_at ON album_favorites(created_at);

-- Indexes for commercial_favorites table
CREATE INDEX IF NOT EXISTS idx_commercial_favorites_user_id ON commercial_favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_commercial_favorites_commercial_post_id ON commercial_favorites(commercial_post_id);
CREATE INDEX IF NOT EXISTS idx_commercial_favorites_created_at ON commercial_favorites(created_at);

-- Indexes for photos table
CREATE INDEX IF NOT EXISTS idx_photos_user_id ON photos(user_id);
CREATE INDEX IF NOT EXISTS idx_photos_location_id ON photos(location_id);
CREATE INDEX IF NOT EXISTS idx_photos_created_at ON photos(created_at);

-- Indexes for albums table
CREATE INDEX IF NOT EXISTS idx_albums_owner_id ON albums(owner_id);
CREATE INDEX IF NOT EXISTS idx_albums_created_at ON albums(created_at);
CREATE INDEX IF NOT EXISTS idx_albums_is_public ON albums(is_public);

-- Indexes for album_photos table
CREATE INDEX IF NOT EXISTS idx_album_photos_album_id ON album_photos(album_id);
CREATE INDEX IF NOT EXISTS idx_album_photos_photo_id ON album_photos(photo_id);

-- Indexes for commercial_posts table
CREATE INDEX IF NOT EXISTS idx_commercial_posts_user_id ON commercial_posts(user_id);
CREATE INDEX IF NOT EXISTS idx_commercial_posts_type ON commercial_posts(type);
CREATE INDEX IF NOT EXISTS idx_commercial_posts_album_id ON commercial_posts(album_id);
CREATE INDEX IF NOT EXISTS idx_commercial_posts_photo_id ON commercial_posts(photo_id);
CREATE INDEX IF NOT EXISTS idx_commercial_posts_is_active ON commercial_posts(is_active);
CREATE INDEX IF NOT EXISTS idx_commercial_posts_created_at ON commercial_posts(created_at);

-- Indexes for users table
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);

-- Indexes for locations table
CREATE INDEX IF NOT EXISTS idx_locations_name ON locations(name);

-- Composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_likes_user_photo ON likes(user_id, photo_id);
CREATE INDEX IF NOT EXISTS idx_comments_photo_created ON comments(photo_id, created_at);
CREATE INDEX IF NOT EXISTS idx_follows_follower_followed ON follows(follower_id, followed_id);
CREATE INDEX IF NOT EXISTS idx_photos_user_created ON photos(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_commercial_posts_type_active ON commercial_posts(type, is_active);
