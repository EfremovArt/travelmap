/**
 * Admin Panel - Common JavaScript Functions
 */

// Initialize when DOM is ready
$(document).ready(function() {
    // Initialize tooltips
    initTooltips();
    
    // Initialize popovers
    initPopovers();
    
    // Add active class to current page in sidebar
    highlightCurrentPage();
});

/**
 * Initialize Bootstrap tooltips
 */
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * Initialize Bootstrap popovers
 */
function initPopovers() {
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}

/**
 * Highlight current page in sidebar
 */
function highlightCurrentPage() {
    const currentPath = window.location.pathname;
    $('.sidebar .nav-link').each(function() {
        const linkPath = $(this).attr('href');
        if (linkPath && currentPath.includes(linkPath)) {
            $(this).addClass('active');
        }
    });
}

/**
 * Show loading spinner
 */
function showLoading(containerId) {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = `
            <div class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Загрузка...</span>
                </div>
            </div>
        `;
    }
}

/**
 * Show error message
 */
function showError(message, title = 'Ошибка') {
    Swal.fire({
        icon: 'error',
        title: title,
        text: message,
        confirmButtonColor: '#3498db'
    });
}

/**
 * Show success message
 */
function showSuccess(message, title = 'Успешно') {
    Swal.fire({
        icon: 'success',
        title: title,
        text: message,
        confirmButtonColor: '#3498db',
        timer: 2000
    });
}

/**
 * Show confirmation dialog
 */
function showConfirmation(message, title = 'Подтверждение') {
    return Swal.fire({
        icon: 'warning',
        title: title,
        text: message,
        showCancelButton: true,
        confirmButtonColor: '#3498db',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Да',
        cancelButtonText: 'Отмена'
    });
}

/**
 * Format date to readable format
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return date.toLocaleDateString('ru-RU', options);
}

/**
 * Format number with thousands separator
 */
function formatNumber(number) {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

/**
 * Truncate text to specified length
 */
function truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substr(0, maxLength) + '...';
}

/**
 * Get user avatar or default
 */
function getUserAvatar(imagePath) {
    if (imagePath && imagePath !== '') {
        return imagePath;
    }
    return '/travel/uploads/default_avatar.png';
}

/**
 * Get photo thumbnail or default
 */
function getPhotoThumbnail(imagePath) {
    if (imagePath && imagePath !== '') {
        return imagePath;
    }
    return '/travel/uploads/default_photo.png';
}

/**
 * Initialize DataTable with common settings
 */
function initDataTable(tableId, options = {}) {
    const defaultOptions = {
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/ru.json'
        },
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        order: [[0, 'desc']],
        responsive: true,
        processing: true
    };
    
    const mergedOptions = { ...defaultOptions, ...options };
    return $(tableId).DataTable(mergedOptions);
}

/**
 * Reload DataTable
 */
function reloadDataTable(table) {
    if (table) {
        table.ajax.reload(null, false);
    }
}

/**
 * Make AJAX request
 */
function makeAjaxRequest(url, method = 'GET', data = null) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: url,
            method: method,
            data: data,
            dataType: 'json',
            success: function(response) {
                resolve(response);
            },
            error: function(xhr, status, error) {
                reject({
                    status: xhr.status,
                    message: error,
                    response: xhr.responseJSON
                });
            }
        });
    });
}

/**
 * Handle AJAX error
 */
function handleAjaxError(error) {
    console.error('AJAX Error:', error);
    
    let message = 'Произошла ошибка при выполнении запроса';
    
    if (error.response && error.response.message) {
        message = error.response.message;
    } else if (error.message) {
        message = error.message;
    }
    
    showError(message);
}

/**
 * Debounce function for search inputs
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Export table to CSV
 */
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    for (let i = 0; i < rows.length; i++) {
        const row = [];
        const cols = rows[i].querySelectorAll('td, th');
        
        for (let j = 0; j < cols.length; j++) {
            row.push(cols[j].innerText);
        }
        
        csv.push(row.join(','));
    }
    
    downloadCSV(csv.join('\n'), filename);
}

/**
 * Download CSV file
 */
function downloadCSV(csv, filename) {
    const csvFile = new Blob([csv], { type: 'text/csv' });
    const downloadLink = document.createElement('a');
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}
